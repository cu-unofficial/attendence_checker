import selenium
from selenium import webdriver
import time
import pandas as pd
import html5lib
from IPython.display import display, HTML
import gc
from datetime import datetime
from datetime import timedelta, date
from app import *
import app
import glob

def attendence_all():
    display(df.iloc[:, 0:14])


def bunk_sub():
    bunk_mang = pd.DataFrame(columns=["Title", "Bunks"])
    row = df.shape[0]

    for i in range(row):
        total_attend = df['Total Attd.'][i]
        total_delv = df['Total Delv.'][i]
        bunk = (total_attend // 0.76) - total_delv
        if bunk < 0:
            bunk = 0
        sub_out = df['Title'][i]
        bunk_mang = bunk_mang.append({"Title": sub_out, "Bunks": bunk}, ignore_index=True)
        glob.bunk_mang=bunk_mang
    display(bunk_mang)


def bunk_sub_specific():
    sub = input('Enter the subject name: ')
    requ = (df[df['Title'].str.match(sub)])
    shape = (requ.shape[0])
    if shape > 1:
        print('Which subject are you looking for:')
        for i in range(shape):
            print("{}: {}".format(i + 1, requ.iloc[i][1]))
        selection = int(input())
    requ = requ.iloc[selection - 1]

    total_attend = int(requ['Total Attd.'])

    total_delv = int(requ['Total Delv.'])
    bunk = (total_attend // 0.76) - total_delv
    if bunk < 0:
        bunk = 0
    sub_out = requ['Title']
    display('Total bunks available for {} are: '.format(sub_out), bunk)


def ninty_att_all():
    top_mang = pd.DataFrame(columns=["Title", "Lectures"])
    row = df.shape[0]

    for i in range(row):
        total_attend = df['Total Attd.'][i]
        total_delv = df['Total Delv.'][i]
        Lecture = round(((total_delv * 0.91) - total_attend) // (0.09))
        if Lecture < 0:
            Lecture = 0
        sub_out = df['Title'][i]
        top_mang = top_mang.append({"Title": sub_out, "Lectures": Lecture}, ignore_index=True)
    glob.top_mang=top_mang
    #display(top_mang)


def time_table():
    global t_table
    start_index_tt = tt.eq('Timing/Day').stack()
    start_index_tt = start_index_tt[start_index_tt].index.values
    start_index_tt = start_index_tt[0][0]
    end_index_tt = tt.eq('3:20 - 4:10 PM').stack()
    end_index_tt = end_index_tt[end_index_tt].index.values
    end_index_tt = end_index_tt[0][0]+1
    t_table = pd.DataFrame(columns=['Timing/Day','Mon','Tue','Wed','Thu','Fri'])
    for row in range(start_index_tt+1,end_index_tt):
        to_insert = tt.iloc[row]
        to_insert.pop(0)
        t_table = t_table.append({'Timing/Day':to_insert[1],'Mon':to_insert[2],'Tue':to_insert[3],'Wed':to_insert[4],'Thu':to_insert[5],'Fri':to_insert[6]},ignore_index=True)
    t_table = t_table.fillna(" ")
    week_days = {
        1:'Mon',
        2:'Tue',
        3:'Wed',
        4:'Thu',
        5:'Fri'
    }
    arrays=[['Mon','Mon','Mon','Tue','Tue','Tue','Wed','Wed','Wed','Thu','Thu','Thu','Fri','Fri','Fri'],
           ['Subject','Room No','Teacher','Subject','Room No','Teacher','Subject','Room No',
            'Teacher','Subject','Room No','Teacher','Subject','Room No','Teacher']]
    tuples = list(zip(*arrays))
    index = pd.MultiIndex.from_tuples(tuples, names=['Days', 'Time'])
    TT=pd.DataFrame(index=['09:30 - 10:20 AM', '10:20 - 11:10 AM', '11:10 - 12:00 PM','12:00 - 12-50 PM',
                          '12:50 - 1:40 PM','1:40 - 2:30 PM','2:30 - 3:20 PM','3:20 - 4:10 PM'],columns=index)
    m=0
    for i in week_days:
        string=(t_table[week_days[i]])
        row = (string.shape[0])
        for j in range(row):
            teacher_name=string[j].split()
            #check if empty
            try:
                room_no=teacher_name[-1]
                room_no = room_no[2:]
            except:
                room_no = ' '
            try:
                sub_code = teacher_name[0]
                sub_code = sub_code.partition(":")[0]
                sub_code = (courses1[courses1['Course Code'].str.match(sub_code)])
                sub_name = sub_code.iloc[0][1]
                #check if empty
                try:
                    sub_name = sub_code.iloc[0][1]
                except:
                    sub_name = ' '
            except:
                sub_name = ' '
            teacher_name=teacher_name[3:-2]
            teacher_name= ' '.join(teacher_name)
            if sub_name == ' ' :
                data = ' '
            else:
                data = [sub_name,room_no,teacher_name]
                #data = ' '.join(data)
            if m%8==0:
                m=0
            TT.loc[TT.index[m],[week_days[i]]] = data
            m+=1
    return TT,t_table



def subs():
    start_index_sub = tt.eq('Course Code').stack()
    start_index_sub = start_index_sub[start_index_sub].index.values
    i=start_index_sub[0][0]
    j=0
    while True:
        if pd.isna(tt.iloc[i][start_index_sub[0][1]]):
            break
        else:
            j+=1
        i+=1
    j-=1

    start_index_sub = start_index_sub[0][0]
    end_index_sub = start_index_sub+j
    courses = pd.DataFrame(columns=['Course Code','Title'])
    for row in range(start_index_sub+1,end_index_sub):
        to_insert = tt.iloc[row]
        courses = courses.append({'Course Code':to_insert[1],'Title':to_insert[2]},ignore_index=True)
    courses = courses.fillna(" ")
    glob.courses=courses
    return courses


def sub_ninty_can_be_achived(last_date):
    # current date
    today = datetime.today()
    today = today.strftime("%d/%m/%Y")

    # strinping the dates to find the numbe of days
    today1 = datetime.strptime(today, "%d/%m/%Y")
    last_date1 = datetime.strptime(last_date, "%d/%m/%Y")
    days = abs((last_date1 - today1).days)

    # day today
    day_today = datetime.now()

    # week day today
    day_today = day_today.isoweekday()
    print(day_today)

    start_date = today1
    end_date = last_date1

    day_count = (end_date - start_date).days + 1
    for single_date in (start_date + timedelta(n) for n in range(day_count)):
        print(single_date.isoweekday())
    # display(t_table1['Mon'])


def date_valid():
    inputDate = input("Enter the date in format 'dd/mm/yy' : ")
    day,month,year = inputDate.split('/')
    isValidDate = True
    try :
        datetime(int(year),int(month),int(day))
    except ValueError :
        isValidDate = False
    if(isValidDate) :
        sub_ninty_can_be_achived(inputDate)
    else :
        print ("Input date is not valid..")


def main():
    driver = webdriver.Firefox()
    print(glob.uid)
    print(glob.password)
    print("Opening: https://uims.cuchd.in/uims/")
    try:
        driver.get('https://uims.cuchd.in/uims/')
    except:
        print("Unable to open the webpage ._.")
    try:
        print("Entering the uid")
        driver.find_element_by_xpath('//*[@id="txtUserId"]').send_keys(glob.uid)
        driver.find_element_by_xpath('//*[@id="btnNext"]').click()
        driver.find_element_by_xpath('//*[@id="txtLoginPassword"]').send_keys(glob.password)
        print("Entering the password")
        driver.find_element_by_xpath('//*[@id="btnLogin"]').click()
    except:
        print("Either the UID or the password entered is incorrect !!")
    time.sleep(2)
    print("login Successful")
    driver.get("https://uims.cuchd.in/UIMS/frmStudentCourseWiseAttendanceSummary.aspx")
    print('Checking Your attendence')
    time.sleep(5)
    global df
    df = pd.read_html(driver.find_element_by_xpath('//*[@id="SortTable"]').get_attribute('outerHTML'))[0]
    print('Coppied your attendence')
    print('Reading Your time table')
    driver.get("https://uims.cuchd.in/UIMS/frmMyTimeTable.aspx")
    time.sleep(5)
    global tt
    tt = pd.read_html(driver.find_element_by_xpath(
        '//*[@id="VisibleReportContentctl00_ContentPlaceHolder1_ReportViewer1_ctl09"]').get_attribute('outerHTML'))[0]
    print('Coppid yor time table')
    driver.quit()

    print('Creating your time table')
    t_table1, t_table = time_table()
    glob.t_table=t_table
    print('Checking Your Subjects')
    courses1 = subs()

    print('Deleting the unrequried resources')
    # free memory
    del [[tt]]
    gc.collect()
    tt = pd.DataFrame()
    '''
    while True:
        # make the function that will tell that is it possible to reach ninty percert in remaining days
        print('1. Attendence of each subject')
        print('2. Subjectwise Bunks Availible(75%)')
        print('3. Bunks for a specific subject(75%)')
        print('4. Lactures requried to reach 90%')
        print('5. Check time table')
        print('6. Check the Subjects and their codes')
        print('7. Wether you could reach 90% attendence')
        print('8. Exit')
        choice = int(input("Enter your choice: "))
        if choice == 1:
            attendence_all()
            input()
        elif choice == 2:
            bunk_sub()
            input()
        elif choice == 3:
            bunk_sub_specific()
            input()
        elif choice == 4:
            ninty_att_all()
            input()
        elif choice == 5:
            print('1. Display detailes time table',
                  '2.Display in easy to read format')
            tt_choice = int(input())
            if tt_choice == 1:
                display(t_table)
            elif tt_choice == 2:
                display(t_table1)
        elif choice == 6:
            display(courses1)
        elif choice == 7:
            date_valid()
            break
        elif choice == 8:
            print('Bye ._.')
            break
    '''

if __name__ == '__main__':
    main()
