from flask import Flask,render_template, request
import todo as todo
from todo import *
import glob
app = Flask(__name__)
app.secret_key = 'some_secret'

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/profile', methods=['POST', 'GET'])
def profile():
    if request.form['btn'] == 'login':
        glob.password = request.values.get('psw')
        glob.uid = request.values.get('uname')
        todo.main()
        return render_template('profile.html')


    if request.form['btn'] == 'Time Table':
        data = glob.t_table
        data = data.to_html(classes=["table table-dark table-striped table-hover"])
        return render_template('profile.html',data=data)


    if request.form['btn'] == 'Bunks (75%)':
        data = glob.bunk_mang
        data = data.to_html(classes=["table table-dark table-striped table-hover"])
        return render_template('profile.html',data=data)


#this functionn is to be activated
    if request.form['btn'] == 'Bunks in a Subject (75%)':
        data = glob.t_table
        data = data.to_html(classes=["table table-dark table-striped table-hover"])
        return render_template('profile.html',data=data)


    if request.form['btn'] == 'Lectures For (91%)':
        data = glob.top_mang
        data = data.to_html(classes=["table table-dark table-striped table-hover"])
        return render_template('profile.html',data=data)


    if request.form['btn'] == 'Your Subjects':
        data = glob.courses
        data = data.to_html(classes=["table table-dark table-striped table-hover"])
        return render_template('profile.html',data=data)
    return render_template('profile.html')


if __name__ == '__main__':
    app.run(debug=True)
